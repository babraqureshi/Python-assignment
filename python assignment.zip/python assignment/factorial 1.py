Python 3.10.6 (tags/v3.10.6:9c7b4bd, Aug  1 2022, 21:53:49) [MSC v.1932 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

= RESTART: D:/01_PERSONAL/02_EDUCATION/IMARITICUS/2022 09 03_PYTHON/SECTION 6 FUNCTION/local.py
enter the number :10
factorial of  10 is  3628800


= RESTART: D:/01_PERSONAL/02_EDUCATION/IMARITICUS/2022 09 03_PYTHON/SECTION 6 FUNCTION/local.py
enter the number :30
factorial of  30 is  265252859812191058636308480000000
